<?php
$id1=$_POST["id"];
$name1=$_POST["name"];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "demo";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$dbname);
// Check connection
if (!$conn) {
die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully <br>";
// Escape all strings
$id = mysqli_real_escape_string($conn, $id1);
$name = mysqli_real_escape_string($conn, $name1);
//inserting into table
$sql = "INSERT INTO customer(id,name) VALUES ('{$id}','{$name}')";
if (mysqli_query($conn, $sql))
{
echo "<script>alert('Congratulations ! added successful.');</script>";
}
else
{
echo "<script>alert('Something went wrong.');window.history.back();</script>";
}
//displaying records
$sql = "SELECT * FROM customer";
$result=mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0)
{
while($row = $result->fetch_assoc()) {
echo "id: " . $row["id"]. " - Name: " . $row["name"] ."<br>";
}
}
//closing connection
mysqli_close($conn);
?>