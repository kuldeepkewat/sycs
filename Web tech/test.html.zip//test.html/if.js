var txt=" "
var person
{
fname:"kuldeep";
lname:"kewat";
age:20;
    
};
var x;
for(x in person)
{
    txt=txt+person(x);
}
document.write(txt);