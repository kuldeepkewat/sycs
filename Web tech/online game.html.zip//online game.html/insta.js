var x=13;
if(x==13){
    document.write("x is equal");
}